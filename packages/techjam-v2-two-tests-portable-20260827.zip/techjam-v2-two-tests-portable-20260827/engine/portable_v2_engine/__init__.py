"""Namespaced portable V2 evaluation engine."""
